﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CapaPresentacion
{
    public partial class Inventario : Form
    {
        CapaNegocio.CNProductos oCN_productos = new CapaNegocio.CNProductos();

        CapaNegocio.CN_Inventario oCN_Inventario = new CapaNegocio.CN_Inventario();

        CapaEntidades.CE_Inventario oCE_Inventario = new CapaEntidades.CE_Inventario();

        DataTable Tabla = new DataTable();
        public Inventario()
        {
            InitializeComponent();
        }

        private void Inventario_Load(object sender, EventArgs e)
        {
            Mostrar();
            
        }

        private void Mostrar()
        {
            dgv_inventario.DataSource = oCN_Inventario.MostrarInventario();
            
        }
        
        

    }
}
