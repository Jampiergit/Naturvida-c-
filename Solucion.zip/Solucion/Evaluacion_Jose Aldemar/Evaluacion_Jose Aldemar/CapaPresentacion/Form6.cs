﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaNegocio;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace CapaPresentacion
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        CEvendedores CEvendedores = new CEvendedores();
        CNvendedores CNvendedores=new CNvendedores();

        private void Form6_Load(object sender, EventArgs e)
        {
            MostarVendedores();
            BuscracmbV();
            BuscracmbVE();

        }



        private void BtnInsertar_Click(object sender, EventArgs e)
        {

            CEvendedores.Codigo =Convert.ToInt32(TxtCodigo.Text);
            CEvendedores.Usuario=TxtContrasena.Text;
            CEvendedores.Contraseña=TxtContrasena.Text;
            CEvendedores.Nombre=TxtNombre.Text;
            CNvendedores.InsertarVendores(CEvendedores);

        }


        #region

        public void MostarVendedores()
        {
        
            DgvVendores.DataSource = CNvendedores.MostrarVendedores();
        
        }
        private void BuscracmbV()
        {
            CmbConsultarVen.DataSource = CNvendedores.MostrarVendedores();
            CmbConsultarVen.ValueMember = "Codigo";
            CmbConsultarVen.DisplayMember = "Nombre";
        }

        private void BuscracmbVE()
        {
            cmbeditarV.DataSource = CNvendedores.MostrarVendedores();
            cmbeditarV.ValueMember = "Codigo";
            cmbeditarV.DisplayMember = "Nombre";
        }

        #endregion

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            int Codigo;
            Codigo = Convert.ToInt32(CmbConsultarVen.SelectedValue.ToString());
            CEvendedores.Codigo = Codigo;
            DgvVendores.DataSource = CNvendedores.buscarVendores(CEvendedores);
        }


        private void BtnMostrar_Click(object sender, EventArgs e)
        {
            MostarVendedores();
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    if (cmbeditarC.S.electedIndex >= 0)
        //    {
        //        TxtCodigo1.Text = DgvProductos.CurrentRow.Cells["codigo"].Value.ToString();
        //        TxtDescripcion1.Text = DgvProductos.CurrentRow.Cells["Descripción"].Value.ToString();
        //        TxtValor1.Text = DgvProductos.CurrentRow.Cells["Valor_unidad"].Value.ToString();
        //        TxtCantidad1.Text = DgvProductos.CurrentRow.Cells["Cantidad"].Value.ToString();
        //    }
        //}
    }
}
