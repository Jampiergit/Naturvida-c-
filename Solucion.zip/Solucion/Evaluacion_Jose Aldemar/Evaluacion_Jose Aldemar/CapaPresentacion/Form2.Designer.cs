﻿namespace CapaPresentacion
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnProductos = new System.Windows.Forms.Button();
            this.BtnFacturacion = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnInventario = new System.Windows.Forms.Button();
            this.BtnVendores = new System.Windows.Forms.Button();
            this.Btncliente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnProductos
            // 
            this.BtnProductos.Location = new System.Drawing.Point(41, 172);
            this.BtnProductos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnProductos.Name = "BtnProductos";
            this.BtnProductos.Size = new System.Drawing.Size(100, 28);
            this.BtnProductos.TabIndex = 0;
            this.BtnProductos.Text = "Productos";
            this.BtnProductos.UseVisualStyleBackColor = true;
            this.BtnProductos.Click += new System.EventHandler(this.BtnProductos_Click);
            // 
            // BtnFacturacion
            // 
            this.BtnFacturacion.Location = new System.Drawing.Point(936, 172);
            this.BtnFacturacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnFacturacion.Name = "BtnFacturacion";
            this.BtnFacturacion.Size = new System.Drawing.Size(100, 28);
            this.BtnFacturacion.TabIndex = 1;
            this.BtnFacturacion.Text = "Facturacion";
            this.BtnFacturacion.UseVisualStyleBackColor = true;
            this.BtnFacturacion.Click += new System.EventHandler(this.BtnFacturacion_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(761, 172);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 28);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnInventario
            // 
            this.btnInventario.Location = new System.Drawing.Point(599, 172);
            this.btnInventario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInventario.Name = "btnInventario";
            this.btnInventario.Size = new System.Drawing.Size(100, 28);
            this.btnInventario.TabIndex = 3;
            this.btnInventario.Text = "Inventario";
            this.btnInventario.UseVisualStyleBackColor = true;
            this.btnInventario.Click += new System.EventHandler(this.btnInventario_Click);
            // 
            // BtnVendores
            // 
            this.BtnVendores.Location = new System.Drawing.Point(440, 172);
            this.BtnVendores.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnVendores.Name = "BtnVendores";
            this.BtnVendores.Size = new System.Drawing.Size(100, 28);
            this.BtnVendores.TabIndex = 4;
            this.BtnVendores.Text = "Vendedores";
            this.BtnVendores.UseVisualStyleBackColor = true;
            this.BtnVendores.Click += new System.EventHandler(this.BtnVendores_Click);
            // 
            // Btncliente
            // 
            this.Btncliente.Location = new System.Drawing.Point(235, 172);
            this.Btncliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btncliente.Name = "Btncliente";
            this.Btncliente.Size = new System.Drawing.Size(100, 28);
            this.Btncliente.TabIndex = 5;
            this.Btncliente.Text = "Cliente";
            this.Btncliente.UseVisualStyleBackColor = true;
            this.Btncliente.Click += new System.EventHandler(this.Btncliente_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 567);
            this.Controls.Add(this.Btncliente);
            this.Controls.Add(this.BtnVendores);
            this.Controls.Add(this.btnInventario);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.BtnFacturacion);
            this.Controls.Add(this.BtnProductos);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnProductos;
        private System.Windows.Forms.Button BtnFacturacion;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnInventario;
        private System.Windows.Forms.Button BtnVendores;
        private System.Windows.Forms.Button Btncliente;
    }
}