﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Datos
{
    public class CD_Inventario
    {
        CDconxion Conexion = new CDconxion();
        SqlDataReader leer;
        DataTable Tabla = new DataTable();
        SqlCommand comando = new SqlCommand();




        public DataTable Mostrar()
        {
            Tabla.Clear();
            comando.Connection = Conexion.abrirconexion();
            comando.CommandText = "SP_BUSCARINVENTARIOS";
            comando.CommandType = CommandType.StoredProcedure;
            leer = comando.ExecuteReader();
            Tabla.Load(leer);
            Conexion.Cerrarconxion();
            return Tabla;

        }

        public DataTable Buscar(CapaEntidades.CE_Inventario Registrar)
        {
            comando.Parameters.Clear();
            comando.Connection = Conexion.abrirconexion();
            comando.CommandText = "SP_BUSCARINVENTARIO";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Prod", Registrar.Prod);
            leer = comando.ExecuteReader();
            Tabla.Load(leer);
            Conexion.Cerrarconxion();
            return Tabla;
        }

        public void Descontar(CapaEntidades.CE_Inventario Registrar)
        {
            
            comando.Connection = Conexion.abrirconexion();
            comando.CommandText = "Hola";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Codprod", Registrar.Codprod);
            comando.Parameters.AddWithValue("@Cantidad", Registrar.Cantidad);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
            Conexion.Cerrarconxion();
        }

    }
}
