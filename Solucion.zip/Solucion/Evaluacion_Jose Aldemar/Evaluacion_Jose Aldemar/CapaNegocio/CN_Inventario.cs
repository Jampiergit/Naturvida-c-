﻿using Capa_Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CN_Inventario
    {
        CD_Inventario oCD_Inventaio = new CD_Inventario();

        public DataTable MostrarInventario()
        {
            DataTable Tabla = new DataTable();
            Tabla = oCD_Inventaio.Mostrar();
            return Tabla;
        }

        public DataTable BuscarInventario(CapaEntidades.CE_Inventario Registrar)
        {
            DataTable Tabla = new DataTable();
            Tabla = oCD_Inventaio.Buscar(Registrar);
            return Tabla;
        }

        public void DescontarInventario(CapaEntidades.CE_Inventario Registrar)
        {
            oCD_Inventaio.Descontar(Registrar);
        }
    }
}
