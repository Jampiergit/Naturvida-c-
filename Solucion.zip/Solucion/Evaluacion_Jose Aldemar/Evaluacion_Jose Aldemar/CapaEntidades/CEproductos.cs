﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class CEproductos
    {

        public int Codigo { get; set; }

        public string Descripcion { get; set; }

        public int Valor_Unidad { get; set; }

        public int Cantidad { get; set; }
     
    }
}
