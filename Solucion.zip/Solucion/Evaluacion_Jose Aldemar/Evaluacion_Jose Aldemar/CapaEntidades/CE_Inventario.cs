﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class CE_Inventario
    {
        public int Prod { get; set; }
        public string Codprod { get; set; }
        public int Cantidad { get; set; }
    }
}
