﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class CEFacturadetalle
    {

        public int IDfac { get; set; }

        public int CodProd { get; set; }

        public int Cant { get; set; }

        public int Valunidad { get; set; }
   
    }
}
